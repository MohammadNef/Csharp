namespace one
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int first = Convert.ToInt32(textBox1.Text);
            int second = Convert.ToInt32(textBox2.Text);
            int All = first + second;
            label3.Text = All.ToString();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int first2 = Convert.ToInt32(textBox1.Text);
            int second2 = Convert.ToInt32(textBox2.Text);
            int All2 = first2 - second2;
            label4.Text = All2.ToString();
        }
    }
}