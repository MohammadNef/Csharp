﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace exam
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Label1_Click(object sender, EventArgs e)
        {
            








        }

        private void buttonDone_Click(object sender, EventArgs e)
        {
            try
            {
                student Inf = new student(textBoxFname.Text, textBoxLname.Text, 
                         textBoxGender.Text, Convert.ToInt16(textBoxAge.Text));

                MessageBox.Show("Your full name is : \t" + Inf.Fname + " " + Inf.Lname + 
               "\n" + "You are " + " " + Inf.age + "\n" + "And you are" + " " + Inf.Gender);
            }
            catch (Exception Er)
            {

                MessageBox.Show("Your information is not valid");
            }
        

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }
}
